# Práctica 1

## Zamora Cruz Diego Arturo - 316249560 

La práctica fue programada y probada con Java 11

Intrucciones de ejecucion
1. Dentro del directorio [src/](src/) ejecutar el comenado `$ javac *.java`
2. A continuacion ejecutar `$ java Practica1`