# Práctica 2

## Zamora Cruz Diego Arturo - 316249560 

La práctica fue programada y probada con

- Spring Boot 2.7.8
- Java: 11
- Eclipse IDE 2022-09

Intrucciones de ejecucion
1. Ejecutamos el programa con la herramienta de su preferencia (Eclipse, Netbeans, etc)
2. Desde el navegador o desde postman nos dirigimos a la sigueinte direccion [http://localhost:8080/category](http://localhost:8080/category) y veremos la siguiente salida 
   
   ```
   [
        {
            "categoryId": 1,
            "category": "Linea Blanca",
            "acronym": "LB"
        },
        {
            "categoryId": 2,
            "category": "Electrónica",
            "acronym": "Electr"
        },
        {
            "categoryId": 3,
            "category": "Casa y Jardin",
            "acronym": "CyJ"
        },
        {
            "categoryId": 4,
            "category": "Mascotas",
            "acronym": "Masc"
        }
    ]
   ```