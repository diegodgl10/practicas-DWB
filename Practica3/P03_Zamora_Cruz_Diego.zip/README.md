# Práctica 3

## Zamora Cruz Diego Arturo - 316249560 

La práctica fue programada y probada con

- Spring Boot 2.7.8
- Java: 11
- Eclipse IDE 2022-09

Instrucciones de ejecución
1. Ejecutamos el programa con la herramienta de su preferencia (Eclipse, Netbeans, etc)
2. Para probar cada método requerido, se utilizó Postman versión 10.10.9.
   Si se desean realizar las mismas pruebas se puede importar el archivo [Category_p3.json](Category_p3.json) que se incluye en el archivo .zip